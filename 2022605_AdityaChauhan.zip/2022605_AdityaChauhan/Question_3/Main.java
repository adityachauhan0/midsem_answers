import java.util.*;
public class Main {
    public static void f(){
        Scanner sc = new Scanner(System.in);
        boolean ran = true;


        System.out.println("Please enter the pincode: ");
        String pincode = sc.next();
        try {
            if (pincode.length() != 6){
                throw new IncorrectPincodeException();
            }
            if(pincode.charAt(0) == '0') {
                throw new IncorrectPincodeException();
            }

        } catch (IncorrectPincodeException e) {
            if (pincode.charAt(0) == '0') {
                System.out.println("Pincode starts with 0");
            }
            if (pincode.length() != 6) {
                System.out.println("Pincode is not of length 6" );
            }
            System.out.println("Please try again");
            f();
        }
    }
    public static void main(String[] args) {


        f();
        System.out.println("pincode successfully entered");



    }
}