import java.util.Objects;

public class Student extends Person{
    public int getCGPA() {
        return CGPA;
    }

    public void setCGPA(int CGPA) {
        this.CGPA = CGPA;
    }

    int CGPA;

    public int getStart_year() {
        return start_year;
    }

    public void setStart_year(int start_year) {
        this.start_year = start_year;
    }

    int start_year;

    public String getResidential_status() {
        return residential_status;
    }

    public void setResidential_status(String residential_status) {
        this.residential_status = residential_status;
    }

    String residential_status;

    Student(String first_name, String last_name, String id, Address address, int CGPA, int start_year, String residential_status ) {
        super();
        this.setFirst_name(first_name);
        this.setLast_name(last_name);
        this.setAddress(address);
        this.setId(id);
        this.setCGPA(CGPA);
        this.setResidential_status(residential_status);
        this.setStart_year(start_year);
    }

    @Override
    void goToWork() {
        if(Objects.equals(this.getResidential_status(), "onCampus")){
            System.out.println("mode of going to work is: walking");
        }
        else System.out.println("mode of going to work is: vehicle");
    }
}
