import java.util.*;
public class Main {
    public static void rankingDistance(List<Student> li){
        Map<Integer, Student> dist = new Map<Integer, Student>();
        List<Integer> ranks = new ArrayList<Integer>();
        for (Student s: li){
            assert false;
            dist.put(Math.abs(s.getAddress().getPincode() - 110020),s);
            Integer e = Math.abs(s.getAddress().getPincode() - 110020);
            ranks.add(e);
        }
        ranks.stream().sorted();
        for (Integer i: ranks){
            System.out.println(dist.get(i));
        }
    }
    public static void main(String[] args) {

        Student s1 = new Student("John","Doe","1",new Address("area_one","mumbai","maharashtra",410210),6,2020,"dayScholar");
        Student s2 = new Student("Jahen","Doe","2",new Address("area_two","mumbai","maharashtra",301023),7,2022,"dayScholar");
        Student s3 = new Student("Jehan","Doe","1",new Address("area_three","mumbai","maharashtra",765432),8,2023,"dayScholar");
        Student s4 = new Student("John","Doe","1",new Address("area_four","mumbai","maharashtra",980234),4,2021,"dayScholar");
        Student s5 = new Student("John","Doe","1",new Address("area_five","mumbai","maharashtra",787878),3,2020,"dayScholar");

        List<Student> students = List.of(s1,s2,s3,s4,s5);
        rankingDistance(students);



    }
}