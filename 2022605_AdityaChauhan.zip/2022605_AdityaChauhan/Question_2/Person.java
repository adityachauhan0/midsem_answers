abstract class Person {
    private String first_name,last_name,id;
    Address address;
    public Person(String first_name, String last_name, String id, Address address){
        this.first_name = first_name;
        this.last_name = last_name;
        this.id = id;
        this.address = address;
    }

    public Person() {

    }


    @Override
    public String toString() {
        return "Person{" +
                "first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", id='" + id + '\'' +
                ", Address='" + address + '\'' +
                '}';
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address _address) {
        address = _address;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    abstract void goToWork();

}
