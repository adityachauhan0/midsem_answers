public class Main {
    public static void main(String[] args) {

        Helicopter h = new Helicopter();
        Rotator rotator = new Rotator();
        Flyer flyer = new Flyer();
        Helicopter helicopter = new Helicopter();

        h.drive(rotator);
        h.drive(flyer);
        h.drive(helicopter);


    }
}