public class Rotator implements Rotatable{
    @Override
    public void rotate() {
        System.out.println("Rotator is rotating");
    }

    @Override
    public String toString() {
        return "this is a Rotator";
    }
}
