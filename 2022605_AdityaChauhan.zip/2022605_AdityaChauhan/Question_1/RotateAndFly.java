public interface RotateAndFly  extends Rotatable{
    public void fly();

}
