public interface Rotatable {
    public void rotate();

}
