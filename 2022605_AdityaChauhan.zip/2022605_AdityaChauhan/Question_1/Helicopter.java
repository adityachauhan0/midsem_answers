public class Helicopter implements RotateAndFly{
    @Override
    public void rotate() {
        System.out.println("Helicopter is rotating");
    }

    @Override
    public void fly() {
        System.out.println("Helicopter is flying");
    }

    public void drive(Rotatable r){
        System.out.println("Helicopter is driving using a rotatable ");
    }

    @Override
    public String toString() {
        return "this is a helicopter";
    }
}
