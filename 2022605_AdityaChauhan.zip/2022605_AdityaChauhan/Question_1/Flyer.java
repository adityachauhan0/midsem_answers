public class Flyer implements RotateAndFly{
    @Override
    public void rotate() {
        System.out.println("Flyer is rotating");
    }

    @Override
    public void fly() {
        System.out.println("Flyer is flying");
    }

    @Override
    public String toString() {
        return "This is a flyer";
    }
}
